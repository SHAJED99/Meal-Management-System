/*******************************************************************************
 * #Author:   SRPPC
 * #Mail:     shajedurrahmanpanna.panna@gmail.com
 * #Date:     Sep 15, 2019
 * #Time:     4:27:47 PM
 * #File:     P000001__CreateConnection_1
 * #Project:  _JavaProject
 ******************************************************************************/

package javaproject;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class P000001__CreateConnection_1 {
    public static Connection ConnectDb(String location){
        try
        {
            Class.forName("org.sqlite.JDBC");
            Connection con = DriverManager.getConnection("jdbc:sqlite:"+location);
            return con;       
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
}
