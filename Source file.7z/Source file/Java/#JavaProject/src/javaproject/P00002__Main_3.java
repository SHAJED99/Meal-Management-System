package javaproject;

import java.sql.Connection;
import javax.swing.JOptionPane;

public class P00002__Main_3 extends javax.swing.JFrame {

    public P00002__Main_3() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        b2 = new javax.swing.JButton();
        b1 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1000, 544));
        setMinimumSize(new java.awt.Dimension(1000, 544));
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(1000, 544));
        setResizable(false);
        getContentPane().setLayout(null);

        b2.setBackground(new java.awt.Color(54, 141, 167));
        b2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        b2.setText("-");
        b2.setToolTipText("Minimize");
        b2.setBorderPainted(false);
        b2.setContentAreaFilled(false);
        b2.setFocusPainted(false);
        b2.setMargin(new java.awt.Insets(-5, 0, 0, 0));
        b2.setMaximumSize(new java.awt.Dimension(7, 15));
        b2.setMinimumSize(new java.awt.Dimension(7, 15));
        b2.setPreferredSize(new java.awt.Dimension(7, 15));
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });
        getContentPane().add(b2);
        b2.setBounds(930, 10, 30, 30);

        b1.setBackground(new java.awt.Color(54, 141, 167));
        b1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        b1.setText("X");
        b1.setToolTipText("Exit");
        b1.setBorderPainted(false);
        b1.setContentAreaFilled(false);
        b1.setFocusable(false);
        b1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        b1.setMaximumSize(new java.awt.Dimension(7, 15));
        b1.setMinimumSize(new java.awt.Dimension(7, 15));
        b1.setPreferredSize(new java.awt.Dimension(7, 15));
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1ActionPerformed(evt);
            }
        });
        getContentPane().add(b1);
        b1.setBounds(960, 10, 30, 30);

        jLabel5.setBackground(new java.awt.Color(153, 153, 153));
        jLabel5.setText("                   Setting");
        jLabel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(jLabel5);
        jLabel5.setBounds(10, 270, 150, 30);

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Add Money");
        jButton2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.setFocusable(false);
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(10, 120, 150, 30);

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Rule");
        jButton3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton3.setFocusable(false);
        jButton3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton3.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(10, 170, 150, 30);

        jButton6.setBackground(new java.awt.Color(36, 174, 216));
        jButton6.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton6.setText("Delete Member");
        jButton6.setBorder(null);
        jButton6.setDebugGraphicsOptions(javax.swing.DebugGraphics.BUFFERED_OPTION);
        jButton6.setFocusPainted(false);
        jButton6.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6);
        jButton6.setBounds(200, 120, 170, 30);

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Add Member");
        jButton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.setFocusable(false);
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(10, 220, 150, 30);

        jButton4.setBackground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Status");
        jButton4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton4.setFocusable(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(10, 70, 150, 30);

        jButton5.setBackground(new java.awt.Color(204, 204, 204));
        jButton5.setText("Log out");
        jButton5.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jButton5.setFocusable(false);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5);
        jButton5.setBounds(10, 490, 150, 30);

        jLabel2.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel2.setText("Menu");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(60, 10, 60, 30);

        jButton7.setBackground(new java.awt.Color(36, 174, 216));
        jButton7.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton7.setText("Edit Password");
        jButton7.setBorder(null);
        jButton7.setDebugGraphicsOptions(javax.swing.DebugGraphics.BUFFERED_OPTION);
        jButton7.setFocusPainted(false);
        jButton7.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton7);
        jButton7.setBounds(200, 70, 170, 30);

        jLabel1.setIcon(new javax.swing.ImageIcon("E:\\Code\\NetBeans\\UI Image\\#JavaProject\\Main\\208960-OZUKI2-299.png")); // NOI18N
        jLabel1.setFocusable(false);
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 1000, 544);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
        int ch = JOptionPane.showConfirmDialog(null, "Do you want to exit?", "Exit?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (ch == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_b1ActionPerformed

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
        this.setState(P00002__Main_01.ICONIFIED);
    }//GEN-LAST:event_b2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        P00002__Main_01 Main = new P00002__Main_01();
        Main.setVisible(true);
        Main.setLocationRelativeTo(null);
        Main.setTitle("Meal Management");
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        P00001__SecondAdminLoginPage_01 SecondAdminLoginPage = new P00001__SecondAdminLoginPage_01();
        SecondAdminLoginPage.setVisible(true);
        SecondAdminLoginPage.setLocationRelativeTo(null);
        SecondAdminLoginPage.setTitle("Meal Management");
        this.setVisible(false);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        P00002__Main_2 Main = new P00002__Main_2();
        Main.setVisible(true);
        Main.setLocationRelativeTo(null);
        Main.setTitle("Meal Management");
        this.setVisible(false);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        String U = JOptionPane.showInputDialog(null, "Enter Old User Name", "Old User Name", JOptionPane.QUESTION_MESSAGE);
        String P = JOptionPane.showInputDialog(null, "Enter Old User Name", "Old User Name", JOptionPane.QUESTION_MESSAGE);

        int x = P000001__ReadInformation_1.MatchPassword(U, P);

        if (x == 1 || x == 2) {
            if (true) {
                String UU = JOptionPane.showInputDialog(null, "Enter New User Name", "New User Name", JOptionPane.QUESTION_MESSAGE);
                String PP = JOptionPane.showInputDialog(null, "Enter New Password", "New Password", JOptionPane.QUESTION_MESSAGE);

                P000001__EditImfo_1 edit = new P000001__EditImfo_1();

                try {
                    Connection con = P000001__CreateConnection_1.ConnectDb("UserInfo.db");
                    int r = P000001__EditImfo_1.editInfo(con, "USER_PASSWORD", "USER_NAME", UU, U, "PASSWORD", PP, P);

                    if (r == 1) {
                        JOptionPane.showMessageDialog(null, "Updated");
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);
                }

            } else if (x == 0) {
                JOptionPane.showMessageDialog(null, "Wrong Username and Password.", "Wrong Information", 1);
            }
        }


    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        P00003__DeleteMember_1 main = new P00003__DeleteMember_1();
        main.setVisible(true);
        main.setLocationRelativeTo(null);
        main.setTitle("Meal Management");
        this.setVisible(false);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        P00002__Main_4 main = new P00002__Main_4();
        main.setVisible(true);
        main.setLocationRelativeTo(null);
        main.setTitle("Meal Management");
        this.setVisible(false);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        P00002__Main_5 main = new P00002__Main_5();
        main.setVisible(true);
        main.setLocationRelativeTo(null);
        main.setTitle("Meal Management");
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    public static void main(String args[]) {
//        P00002__Main_3 main = new P00002__Main_3();
//        main.setVisible(true);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
}
