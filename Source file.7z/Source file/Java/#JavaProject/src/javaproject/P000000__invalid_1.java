/*******************************************************************************
 * #Author:   SRPPC
 * #Mail:     shajedurrahmanpanna.panna@gmail.com
 * #Date:     Sep 19, 2019
 * #Time:     2:48:23 AM
 * #File:     P000000__invalid_1
 * #Project:  _JavaProject
 ******************************************************************************/

package javaproject;

public class P000000__invalid_1 {
    public static void main(String[] args) {
        String[] caldate = {"one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty", "twentyone", "twentytwo", "twentythree", "twentyfour", "twentyfive", "twentysix", "twentyseven", "twentyeight", "twentynine", "thirty", "thirtyone"};
        for (int i = 0; i <= 30; i++) {
            System.out.print(caldate[i]+", ");
        }
    }
}
