/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaproject;

import com.sun.glass.events.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author SRPPC
 */
public class P00002__Main_5 extends javax.swing.JFrame {

    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    

    public P00002__Main_5() {
        initComponents();

        

        updateTable();
    }

    public void updateTable() {
        DefaultTableModel model = new DefaultTableModel();
        Object col1[] = {"ID", "NAME", "MONEY", "REMAINING"};
        model.setColumnIdentifiers(col1);
        T1.setModel(model);
        con = P000001__CreateConnection_1.ConnectDb("StudentInfo.db");
        if (con != null) {
            String sql = "Select ID, NAME, MONEY from StudentInfo";

            try {
                pst = con.prepareStatement(sql);
                rs = pst.executeQuery();
                Object[] columnData = new Object[4];
                while (rs.next()) {
                    columnData[0] = rs.getString("ID");
                    columnData[1] = rs.getString("NAME");
                    columnData[2] = rs.getString("MONEY");
                    columnData[3] = String.valueOf(P000001__ReadInformation_1.aftermeal(rs.getString("ID")));
                    model.addRow(columnData);

                }
                con.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        b1 = new javax.swing.JButton();
        b2 = new javax.swing.JButton();
        b3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        T1 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        id = new javax.swing.JTextField();
        money = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1000, 544));
        setUndecorated(true);
        setSize(new java.awt.Dimension(1000, 544));
        getContentPane().setLayout(null);

        b1.setBackground(new java.awt.Color(54, 141, 167));
        b1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        b1.setText("X");
        b1.setToolTipText("Exit");
        b1.setBorderPainted(false);
        b1.setContentAreaFilled(false);
        b1.setFocusable(false);
        b1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        b1.setMaximumSize(new java.awt.Dimension(7, 15));
        b1.setMinimumSize(new java.awt.Dimension(7, 15));
        b1.setPreferredSize(new java.awt.Dimension(7, 15));
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1ActionPerformed(evt);
            }
        });
        getContentPane().add(b1);
        b1.setBounds(960, 10, 30, 30);

        b2.setBackground(new java.awt.Color(54, 141, 167));
        b2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        b2.setText("-");
        b2.setToolTipText("Minimize");
        b2.setBorderPainted(false);
        b2.setContentAreaFilled(false);
        b2.setFocusPainted(false);
        b2.setMargin(new java.awt.Insets(-5, 0, 0, 0));
        b2.setMaximumSize(new java.awt.Dimension(7, 15));
        b2.setMinimumSize(new java.awt.Dimension(7, 15));
        b2.setPreferredSize(new java.awt.Dimension(7, 15));
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });
        getContentPane().add(b2);
        b2.setBounds(930, 10, 30, 30);

        b3.setBackground(new java.awt.Color(54, 141, 167));
        b3.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        b3.setText("Add");
        b3.setBorder(null);
        b3.setDebugGraphicsOptions(javax.swing.DebugGraphics.BUFFERED_OPTION);
        b3.setFocusPainted(false);
        b3.setMargin(new java.awt.Insets(0, 0, 0, 0));
        b3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b3ActionPerformed(evt);
            }
        });
        getContentPane().add(b3);
        b3.setBounds(740, 500, 150, 30);

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Rule");
        jButton2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.setFocusable(false);
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(10, 170, 150, 30);

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Status");
        jButton3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton3.setFocusable(false);
        jButton3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton3.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(10, 70, 150, 30);

        jLabel5.setBackground(new java.awt.Color(153, 153, 153));
        jLabel5.setText("               Add Money");
        jLabel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(jLabel5);
        jLabel5.setBounds(10, 120, 150, 30);

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Add Member");
        jButton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.setFocusable(false);
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(10, 220, 150, 30);

        jButton4.setBackground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Setting");
        jButton4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton4.setFocusable(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(10, 270, 150, 30);

        jButton5.setBackground(new java.awt.Color(204, 204, 204));
        jButton5.setText("Log out");
        jButton5.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jButton5.setFocusable(false);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5);
        jButton5.setBounds(10, 490, 150, 30);

        jLabel2.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel2.setText("Menu");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(60, 10, 60, 30);

        jLabel3.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel3.setText("Rule");
        jLabel3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(jLabel3);
        jLabel3.setBounds(570, 20, 70, 22);

        T1.setAutoCreateRowSorter(true);
        T1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        T1.setFont(new java.awt.Font("Tahoma", 0, 9)); // NOI18N
        T1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NAME", "MONEY", "REMAINING"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        T1.setEnabled(false);
        T1.setFocusable(false);
        T1.setGridColor(new java.awt.Color(0, 0, 0));
        T1.setRequestFocusEnabled(false);
        T1.setRowHeight(20);
        T1.setSelectionBackground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(T1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(190, 60, 430, 470);

        jLabel4.setText("ID");
        jLabel4.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentMoved(java.awt.event.ComponentEvent evt) {
                jLabel4ComponentMoved(evt);
            }
        });
        getContentPane().add(jLabel4);
        jLabel4.setBounds(630, 130, 130, 30);

        jLabel6.setText("MONEY:");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(630, 160, 130, 30);

        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });
        id.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                idKeyTyped(evt);
            }
        });
        getContentPane().add(id);
        id.setBounds(760, 130, 80, 30);

        money.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                moneyActionPerformed(evt);
            }
        });
        money.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                moneyKeyTyped(evt);
            }
        });
        getContentPane().add(money);
        money.setBounds(760, 160, 80, 30);
        getContentPane().add(jLabel7);
        jLabel7.setBounds(840, 160, 150, 30);

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(153, 153, 153));
        jLabel8.setText("Press enter to update the information");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(630, 190, 210, 13);

        jLabel1.setIcon(new javax.swing.ImageIcon("E:\\Code\\NetBeans\\UI Image\\#JavaProject\\Main\\208960-OZUKI2-299.png")); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 1000, 544);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
        int ch = JOptionPane.showConfirmDialog(null, "Do you want to exit?", "Exit?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (ch == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_b1ActionPerformed

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
        this.setState(P00002__Main_01.ICONIFIED);
    }//GEN-LAST:event_b2ActionPerformed

    private void b3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b3ActionPerformed
        String ids = money.getText();
        String mon = id.getText();
        
        
        if (ids.length() != 0 && mon.length()!=0) {
            String bef = P000001__ReadInformation_1.ReadSingleInfoFromTable("StudentInfo.db", "StudentInfo", "MONEY", "ID", mon);
            int x = Integer.valueOf(ids);
            x = x + Integer.valueOf(bef);
            
            Connection con = P000001__CreateConnection_1.ConnectDb("StudentInfo.db");
            int dic = P000001__EditImfo_1.editInfo(con, "StudentInfo", "MONEY", "ID", String.valueOf(x), mon);
            
            if(dic>0)
                JOptionPane.showMessageDialog(null, "Update Successfull");
            else
                JOptionPane.showMessageDialog(null, "Failed");
        }

        updateTable();
    }//GEN-LAST:event_b3ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        P00002__Main_2 Main = new P00002__Main_2();
        Main.setVisible(true);
        Main.setLocationRelativeTo(null);
        Main.setTitle("Meal Management");
        this.setVisible(false);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        P00002__Main_01 Main = new P00002__Main_01();
        Main.setVisible(true);
        Main.setLocationRelativeTo(null);
        Main.setTitle("Meal Management");
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        P00002__Main_3 main = new P00002__Main_3();
        main.setVisible(true);
        main.setLocationRelativeTo(null);
        main.setTitle("Meal Management");
        this.setVisible(false);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        P00001__SecondAdminLoginPage_01 SecondAdminLoginPage = new P00001__SecondAdminLoginPage_01();
        SecondAdminLoginPage.setVisible(true);
        SecondAdminLoginPage.setLocationRelativeTo(null);
        SecondAdminLoginPage.setTitle("Meal Management");
        this.setVisible(false);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        P00002__Main_4 main = new P00002__Main_4();
        main.setVisible(true);
        main.setLocationRelativeTo(null);
        main.setTitle("Meal Management");
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed
        String ids = id.getText();

        if (ids.length() != 0) {
            int x = P000001__CountMember_1.countmemberint("StudentInfo.db", "StudentInfo", "ID");
            int xx = Integer.valueOf(ids);
            if (xx > 0 && xx <= x)
            {
                String bef = P000001__ReadInformation_1.ReadSingleInfoFromTable("StudentInfo.db", "StudentInfo", "MONEY", "ID", ids);

                jLabel6.setText("MONEY:   " + bef + " + ");
                jLabel7.setText(" =  " + bef);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Wrong Information");
                jLabel6.setText("MONEY:   ");
                jLabel7.setText("");
            }
        } else {
            jLabel6.setText("MONEY:   ");
            jLabel7.setText("");
        }
    }//GEN-LAST:event_idActionPerformed

    private void moneyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_moneyActionPerformed
        String ids = money.getText();
        
        String bef = P000001__ReadInformation_1.ReadSingleInfoFromTable("StudentInfo.db", "StudentInfo", "MONEY", "ID", id.getText());
        if (ids.length() != 0) {
            int x = Integer.valueOf(ids);
            x = x + Integer.valueOf(bef);
            jLabel7.setText(" =  " + x);
        } else {
            jLabel7.setText(" =  " + bef);
        }

    }//GEN-LAST:event_moneyActionPerformed

    private void moneyKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_moneyKeyTyped
        char c = evt.getKeyChar();

        if ((Character.isAlphabetic(c)) || (c == KeyEvent.VK_BACKSPACE) || (c == KeyEvent.VK_DELETE)) {
            evt.consume();
        }
    }//GEN-LAST:event_moneyKeyTyped

    private void idKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_idKeyTyped
        char c = evt.getKeyChar();

        if (!(Character.isDigit(c)) || (c == KeyEvent.VK_BACKSPACE) || (c == KeyEvent.VK_DELETE)) {
            evt.consume();
        }
    }//GEN-LAST:event_idKeyTyped

    private void jLabel4ComponentMoved(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jLabel4ComponentMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel4ComponentMoved

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
//        P00002__Main_5 main = new P00002__Main_5();
//        main.setVisible(true);
//        main.setLocationRelativeTo(null);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable T1;
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JButton b3;
    private javax.swing.JTextField id;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField money;
    // End of variables declaration//GEN-END:variables
}
