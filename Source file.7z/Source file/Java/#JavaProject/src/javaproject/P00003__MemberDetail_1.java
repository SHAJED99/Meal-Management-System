/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaproject;

import com.sun.glass.events.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author SRPPC
 */
public class P00003__MemberDetail_1 extends javax.swing.JFrame {

    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    public P00003__MemberDetail_1() {
        initComponents();

        updateTable();
    }

    public void updateTable() {
        DefaultTableModel model = new DefaultTableModel();
        Object col1[] = {"ID", "NAME"};
        model.setColumnIdentifiers(col1);
        T1.setModel(model);
        con = P000001__CreateConnection_1.ConnectDb("StudentInfo.db");
        if (con != null) {
            String sql = "Select ID, NAME from StudentInfo";

            try {
                pst = con.prepareStatement(sql);
                rs = pst.executeQuery();
                Object[] columnData = new Object[2];
                while (rs.next()) {
                    columnData[0] = rs.getString("ID");
                    columnData[1] = rs.getString("NAME");
                    model.addRow(columnData);

                }
                con.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        b1 = new javax.swing.JButton();
        b2 = new javax.swing.JButton();
        idt = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        T1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        name = new javax.swing.JLabel();
        id = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        mail = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        st = new javax.swing.JTextArea();
        job_study = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        mobile = new javax.swing.JLabel();
        fmobile = new javax.swing.JLabel();
        mother = new javax.swing.JLabel();
        father = new javax.swing.JLabel();
        job_study1 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        money = new javax.swing.JLabel();
        meal = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1200, 544));
        setMinimumSize(new java.awt.Dimension(1200, 544));
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(1200, 544));
        setSize(new java.awt.Dimension(1200, 544));
        getContentPane().setLayout(null);

        b1.setBackground(new java.awt.Color(54, 141, 167));
        b1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        b1.setText("X");
        b1.setToolTipText("Exit");
        b1.setBorderPainted(false);
        b1.setContentAreaFilled(false);
        b1.setFocusable(false);
        b1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        b1.setMaximumSize(new java.awt.Dimension(7, 15));
        b1.setMinimumSize(new java.awt.Dimension(7, 15));
        b1.setPreferredSize(new java.awt.Dimension(7, 15));
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1ActionPerformed(evt);
            }
        });
        getContentPane().add(b1);
        b1.setBounds(1150, 10, 40, 30);

        b2.setBackground(new java.awt.Color(54, 141, 167));
        b2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        b2.setText("-");
        b2.setToolTipText("Minimize");
        b2.setBorderPainted(false);
        b2.setContentAreaFilled(false);
        b2.setFocusPainted(false);
        b2.setMargin(new java.awt.Insets(-5, 0, 0, 0));
        b2.setMaximumSize(new java.awt.Dimension(7, 15));
        b2.setMinimumSize(new java.awt.Dimension(7, 15));
        b2.setPreferredSize(new java.awt.Dimension(7, 15));
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });
        getContentPane().add(b2);
        b2.setBounds(1120, 10, 40, 30);

        idt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idtActionPerformed(evt);
            }
        });
        idt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                idtKeyTyped(evt);
            }
        });
        getContentPane().add(idt);
        idt.setBounds(40, 500, 70, 30);

        jLabel1.setText("ID");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(20, 500, 20, 30);

        jButton1.setBackground(new java.awt.Color(54, 141, 167));
        jButton1.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton1.setText("Back");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.setBorderPainted(false);
        jButton1.setFocusable(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(130, 500, 90, 30);

        T1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NAME"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        T1.setEnabled(false);
        T1.setFocusable(false);
        jScrollPane1.setViewportView(T1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(10, 10, 210, 460);

        jLabel2.setForeground(new java.awt.Color(153, 153, 153));
        jLabel2.setText("            Select ID to get Detail");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(20, 470, 190, 20);

        jLabel4.setText("Family Mobile Number :");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(740, 90, 130, 20);
        getContentPane().add(name);
        name.setBounds(350, 70, 290, 20);
        getContentPane().add(id);
        id.setBounds(350, 50, 290, 20);

        jLabel8.setText("Mother :");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(740, 70, 130, 20);

        jLabel9.setText("Father :");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(740, 50, 130, 20);

        jTextArea1.setEditable(false);
        jTextArea1.setBackground(new java.awt.Color(204, 204, 255));
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Tahoma", 0, 11)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setFocusable(false);
        jScrollPane2.setViewportView(jTextArea1);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(740, 170, 420, 140);
        getContentPane().add(mail);
        mail.setBounds(350, 110, 290, 20);

        st.setEditable(false);
        st.setBackground(new java.awt.Color(204, 204, 255));
        st.setColumns(20);
        st.setFont(new java.awt.Font("Tahoma", 0, 11)); // NOI18N
        st.setRows(5);
        st.setFocusable(false);
        jScrollPane3.setViewportView(st);

        getContentPane().add(jScrollPane3);
        jScrollPane3.setBounds(280, 170, 420, 140);

        job_study.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        job_study.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(job_study);
        job_study.setBounds(280, 140, 420, 14);

        jLabel11.setText("Meal :");
        getContentPane().add(jLabel11);
        jLabel11.setBounds(280, 360, 70, 20);

        jLabel12.setText("Name :");
        getContentPane().add(jLabel12);
        jLabel12.setBounds(280, 70, 70, 20);

        jLabel13.setText("ID :");
        getContentPane().add(jLabel13);
        jLabel13.setBounds(280, 50, 70, 20);

        jLabel14.setText("Money :");
        getContentPane().add(jLabel14);
        jLabel14.setBounds(280, 340, 70, 20);
        getContentPane().add(mobile);
        mobile.setBounds(350, 90, 290, 20);
        getContentPane().add(fmobile);
        fmobile.setBounds(880, 90, 250, 20);
        getContentPane().add(mother);
        mother.setBounds(880, 70, 250, 20);
        getContentPane().add(father);
        father.setBounds(880, 50, 250, 20);

        job_study1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        job_study1.setText("Address");
        job_study1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(job_study1);
        job_study1.setBounds(740, 140, 420, 14);

        jLabel15.setText("Mail :");
        getContentPane().add(jLabel15);
        jLabel15.setBounds(280, 110, 70, 20);

        jLabel16.setText("Mobile :");
        getContentPane().add(jLabel16);
        jLabel16.setBounds(280, 90, 70, 20);
        getContentPane().add(money);
        money.setBounds(350, 340, 70, 20);
        getContentPane().add(meal);
        meal.setBounds(350, 360, 70, 20);

        jLabel3.setIcon(new javax.swing.ImageIcon("E:\\Code\\NetBeans\\UI Image\\#JavaProject\\Member Detail\\208960-OZUKI2-299.png")); // NOI18N
        getContentPane().add(jLabel3);
        jLabel3.setBounds(0, 0, 1200, 544);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
        int ch = JOptionPane.showConfirmDialog(null, "Do you want to exit?", "Exit?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (ch == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_b1ActionPerformed

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
        this.setState(P00002__Main_01.ICONIFIED);
    }//GEN-LAST:event_b2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        P00002__Main_2 Main = new P00002__Main_2();
        Main.setVisible(true);
        Main.setLocationRelativeTo(null);
        Main.setTitle("Meal Management");
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void idtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idtActionPerformed
        String NUM = idt.getText();
        

        if (NUM.length() != 0) {
            int x = P000001__CountMember_1.countmemberint("StudentInfo.db", "StudentInfo", "ID");
            int xx = Integer.valueOf(NUM);
            if (xx > 0 && xx <= x) {
                id.setText(P000001__ReadInformation_1.ReadSingleInfoFromTable("StudentInfo.db", "StudentInfo", "ID", "ID", NUM));
                name.setText(P000001__ReadInformation_1.ReadSingleInfoFromTable("StudentInfo.db", "StudentInfo", "NAME", "ID", NUM));
                mobile.setText(P000001__ReadInformation_1.ReadSingleInfoFromTable("StudentInfo.db", "StudentInfo", "MOBILE", "ID", NUM));
                mail.setText(P000001__ReadInformation_1.ReadSingleInfoFromTable("StudentInfo.db", "StudentInfo", "MAIL", "ID", NUM));
                job_study.setText(P000001__ReadInformation_1.ReadSingleInfoFromTable("StudentInfo.db", "StudentInfo", "JOB_STUDY", "ID", NUM));
                st.setText(P000001__ReadInformation_1.ReadSingleInfoFromTable("StudentInfo.db", "StudentInfo", "DETAILS", "ID", NUM));
                father.setText(P000001__ReadInformation_1.ReadSingleInfoFromTable("StudentInfo.db", "StudentInfo", "F_NAME", "ID", NUM));
                mother.setText(P000001__ReadInformation_1.ReadSingleInfoFromTable("StudentInfo.db", "StudentInfo", "M_NAME", "ID", NUM));
                fmobile.setText(P000001__ReadInformation_1.ReadSingleInfoFromTable("StudentInfo.db", "StudentInfo", "P_MOBILE", "ID", NUM));
                jTextArea1.setText(P000001__ReadInformation_1.ReadSingleInfoFromTable("StudentInfo.db", "StudentInfo", "ADDRESS", "ID", NUM));
                money.setText(P000001__ReadInformation_1.ReadSingleInfoFromTable("StudentInfo.db", "StudentInfo", "MONEY", "ID", NUM));
                meal.setText(P000001__ReadInformation_1.ReadSingleInfoFromTable("StudentInfo.db", "StudentInfo", "TOTAL_MEAL", "ID", NUM));

            } else {
                JOptionPane.showMessageDialog(null, "Wrong Information");
                enpty();
            }
        } else {
            enpty();
        }
    }//GEN-LAST:event_idtActionPerformed

    public void enpty() {
        id.setText("");
        name.setText("");
        mobile.setText("");
        mail.setText("");
        job_study.setText("");
        st.setText("");
        father.setText("");
        mother.setText("");
        fmobile.setText("");
        jTextArea1.setText("");
        money.setText("");
        meal.setText("");
    }

    private void idtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_idtKeyTyped
        char c = evt.getKeyChar();

        if (!(Character.isDigit(c)) || (c == KeyEvent.VK_BACKSPACE) || (c == KeyEvent.VK_DELETE)) {
            evt.consume();
        }
    }//GEN-LAST:event_idtKeyTyped

    public static void main(String args[]) {
//        P00003__MemberDetail_1 Main = new P00003__MemberDetail_1();
//        Main.setVisible(true);
//        Main.setLocationRelativeTo(null);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable T1;
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JLabel father;
    private javax.swing.JLabel fmobile;
    private javax.swing.JLabel id;
    private javax.swing.JTextField idt;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel job_study;
    private javax.swing.JLabel job_study1;
    private javax.swing.JLabel mail;
    private javax.swing.JLabel meal;
    private javax.swing.JLabel mobile;
    private javax.swing.JLabel money;
    private javax.swing.JLabel mother;
    private javax.swing.JLabel name;
    private javax.swing.JTextArea st;
    // End of variables declaration//GEN-END:variables
}
