package javaproject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class P00001__SecondAdminLoginPage_01 extends javax.swing.JFrame {
    
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    
    
    public P00001__SecondAdminLoginPage_01() {
        initComponents();               
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        popupMenu1 = new java.awt.PopupMenu();
        popupMenu2 = new java.awt.PopupMenu();
        b2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        b1 = new javax.swing.JButton();
        t1 = new javax.swing.JTextField();
        p1 = new javax.swing.JPasswordField();
        x = new javax.swing.JButton();
        final javax.swing.JLabel jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        popupMenu1.setLabel("popupMenu1");

        popupMenu2.setLabel("popupMenu2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(null);

        b2.setBackground(new java.awt.Color(54, 141, 167));
        b2.setText("Developer");
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });
        getContentPane().add(b2);
        b2.setBounds(200, 400, 110, 23);

        jLabel4.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel4.setText("Admin");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(236, 110, 80, 30);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel3.setText("Mail: shajedurrahmanpanna.panna@gmail.com");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(150, 450, 240, 20);

        b1.setBackground(new java.awt.Color(54, 141, 167));
        b1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        b1.setText("Login");
        b1.setToolTipText("Login");
        b1.setBorder(null);
        b1.setBorderPainted(false);
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1ActionPerformed(evt);
            }
        });
        getContentPane().add(b1);
        b1.setBounds(140, 310, 230, 50);

        t1.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        t1.setForeground(new java.awt.Color(102, 102, 255));
        t1.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        t1.setText("admin");
        t1.setBorder(null);
        t1.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        t1.setMaximumSize(new java.awt.Dimension(0, 0));
        //t1.setBackground(new java.awt.Color(0, 0, 0, 0))
        t1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t1ActionPerformed(evt);
            }
        });
        getContentPane().add(t1);
        t1.setBounds(190, 159, 170, 40);

        p1.setForeground(new java.awt.Color(102, 102, 255));
        p1.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        p1.setText("admin");
        p1.setBorder(null);
        p1.setPreferredSize(new java.awt.Dimension(35, 15));
        //p1.setBackground(new java.awt.Color(0, 0, 0, 0))
        p1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p1ActionPerformed(evt);
            }
        });
        getContentPane().add(p1);
        p1.setBounds(190, 228, 170, 40);

        x.setBackground(new java.awt.Color(54, 141, 167));
        x.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        x.setText("X");
        x.setToolTipText("Exit");
        x.setBorder(null);
        x.setBorderPainted(false);
        x.setFocusable(false);
        x.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                xActionPerformed(evt);
            }
        });
        getContentPane().add(x);
        x.setBounds(440, 10, 40, 23);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel1.setText("This is a PERSONAL SOFTWARE. If you want to use this software please contuct with the developer."); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(20, 430, 460, 30);

        jLabel2.setIcon(new javax.swing.ImageIcon("E:\\Code\\NetBeans\\UI Image\\#JavaProject\\Login\\Vector Love Pattern Background.jpg.png")); // NOI18N
        jLabel2.setText("X");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 490, 500);

        setSize(new java.awt.Dimension(490, 500));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void t1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_t1ActionPerformed
    int n=0;
    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
        
        String s1=t1.getText();
        String s2=p1.getText();
        
        int dic = P000001__ReadInformation_1.MatchPassword(s1, s2);
        
        if(n==0)
            if(dic==2 && s1.equals("admin") && s2.equals("admin"))
            {
                P00002__Main_2 Main = new P00002__Main_2();
                Main.setVisible(true);
                Main.setLocationRelativeTo(null);
                Main.setTitle("Meal Management");
                this.setVisible(false);
                n++;
            }
            else if(dic==1)
            {
                P00002__Main_2 Main = new P00002__Main_2();
                Main.setVisible(true);
                Main.setLocationRelativeTo(null);
                Main.setTitle("Meal Management");
                this.setVisible(false);
                n++;
            }
            
            else if(dic==0)
            {
                JOptionPane.showMessageDialog(null, "Wrong Username and Password.", "Wrong Information", 1);
                p1.setText(null);
            }
    }//GEN-LAST:event_b1ActionPerformed

    private void p1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_p1ActionPerformed

    private void xActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_xActionPerformed
        System.exit(0);
    }//GEN-LAST:event_xActionPerformed

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
        P00001__MainAdminLoginPage_01 MainAdminLoginPage = new P00001__MainAdminLoginPage_01();
        MainAdminLoginPage.setVisible(true);
        MainAdminLoginPage.setLocationRelativeTo(null);
        MainAdminLoginPage.setTitle("Meal Management");
        this.setVisible(false);
                
        
    }//GEN-LAST:event_b2ActionPerformed

    public static void main(String args[]) {
        
//        P00001__SecondAdminLoginPage_01 SecondAdminLoginPage = new P00001__SecondAdminLoginPage_01();
//        SecondAdminLoginPage.setVisible(true);
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPasswordField p1;
    private java.awt.PopupMenu popupMenu1;
    private java.awt.PopupMenu popupMenu2;
    private javax.swing.JTextField t1;
    private javax.swing.JButton x;
    // End of variables declaration//GEN-END:variables
}
