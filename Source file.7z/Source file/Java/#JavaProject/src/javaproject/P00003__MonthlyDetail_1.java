/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaproject;

import com.sun.glass.events.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class P00003__MonthlyDetail_1 extends javax.swing.JFrame {

    String[] caldate = {"one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty", "twentyone", "twentytwo", "twentythree", "twentyfour", "twentyfive", "twentysix", "twentyseven", "twentyeight", "twentynine", "thirty", "thirtyone"};
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    int membr = P000001__CountMember_1.countmemberint("StudentInfo.db", "StudentInfo", "ID");
    Calendar calendar = Calendar.getInstance();
    int cYear = calendar.get(Calendar.YEAR);
    int cmonth = calendar.get(Calendar.MONTH);
    int cday = calendar.get(Calendar.DATE);
    int maxday = calendar.getActualMaximum(calendar.DAY_OF_MONTH);

    public P00003__MonthlyDetail_1() {
        initComponents();

        year.setText(String.valueOf(cYear) + "     " + String.valueOf(cmonth + 1) + "     " + String.valueOf(cday));
        year1.setText(String.valueOf(cYear) + " / " + String.valueOf(cmonth + 1 + " / "));

        updateTable();
    }

    public void updateTable() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Name");

        for (int i = 1; i <= maxday; i++) {
            model.addColumn(i);
        }

        T1.setModel(model);
        con = P000001__CreateConnection_1.ConnectDb("StudentInfo.db");
        if (con != null) {
            StringBuffer sql = new StringBuffer("Select ID, NAME, ");
            int ii = maxday-1; 
            for (int date = 0; date < ii; date++) {
                sql.append(caldate[date] + ", ");
            }

            sql.append(caldate[maxday-1] + " from StudentInfo");

//            System.out.println(sql);
            try {
                pst = con.prepareStatement(String.valueOf(sql));
                rs = pst.executeQuery();
                Object[] columnData = new Object[maxday + 10];
                while (rs.next()) {
                    columnData[0] = rs.getString("ID");
                    columnData[1] = rs.getString("NAME");

                    for (int i = 2, date = 0; i <= maxday + 1; i++, date++) {
                        columnData[i] = rs.getString(caldate[date]);
//                        System.out.print(caldate[date] + " ");
                    }
                    model.addRow(columnData);

                }
                con.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        b2 = new javax.swing.JButton();
        b1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        T1 = new javax.swing.JTable();
        year = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        id = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        year1 = new javax.swing.JLabel();
        date = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        mealnum = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1300, 700));
        setMinimumSize(new java.awt.Dimension(1300, 700));
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(1300, 700));
        setResizable(false);
        setSize(new java.awt.Dimension(1300, 700));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(null);

        b2.setBackground(new java.awt.Color(54, 141, 167));
        b2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        b2.setText("-");
        b2.setToolTipText("Minimize");
        b2.setBorderPainted(false);
        b2.setContentAreaFilled(false);
        b2.setFocusPainted(false);
        b2.setMargin(new java.awt.Insets(-5, 0, 0, 0));
        b2.setMaximumSize(new java.awt.Dimension(7, 15));
        b2.setMinimumSize(new java.awt.Dimension(7, 15));
        b2.setPreferredSize(new java.awt.Dimension(7, 15));
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });
        getContentPane().add(b2);
        b2.setBounds(1220, 10, 40, 30);

        b1.setBackground(new java.awt.Color(54, 141, 167));
        b1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        b1.setText("X");
        b1.setToolTipText("Exit");
        b1.setBorderPainted(false);
        b1.setContentAreaFilled(false);
        b1.setFocusable(false);
        b1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        b1.setMaximumSize(new java.awt.Dimension(7, 15));
        b1.setMinimumSize(new java.awt.Dimension(7, 15));
        b1.setPreferredSize(new java.awt.Dimension(7, 15));
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1ActionPerformed(evt);
            }
        });
        getContentPane().add(b1);
        b1.setBounds(1250, 10, 40, 30);

        T1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        T1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        T1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        T1.setEnabled(false);
        T1.setFocusable(false);
        jScrollPane1.setViewportView(T1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(10, 50, 1280, 600);

        year.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        year.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(year);
        year.setBounds(520, 10, 230, 30);

        jButton1.setBackground(new java.awt.Color(54, 141, 167));
        jButton1.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton1.setText("Back");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.setBorderPainted(false);
        jButton1.setFocusable(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(10, 660, 90, 30);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ID :");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(780, 660, 30, 30);

        id.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                idKeyTyped(evt);
            }
        });
        getContentPane().add(id);
        id.setBounds(810, 660, 80, 30);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Meal Number :");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(900, 660, 90, 30);

        jButton2.setText("Update");
        jButton2.setFocusPainted(false);
        jButton2.setFocusable(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(1080, 660, 90, 30);

        year1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        year1.setForeground(new java.awt.Color(255, 255, 255));
        year1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        getContentPane().add(year1);
        year1.setBounds(120, 660, 120, 30);

        date.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dateKeyTyped(evt);
            }
        });
        getContentPane().add(date);
        date.setBounds(240, 660, 70, 30);

        jButton3.setText("Full");
        jButton3.setToolTipText("Full meal for all members");
        jButton3.setFocusPainted(false);
        jButton3.setFocusable(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(440, 660, 90, 30);

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Full Meal :");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(320, 660, 70, 30);

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText(P000001__ReadInformation_1.ReadSingleInfo("UserInfo.db", "Rule", "Meal_PerDay"));
        getContentPane().add(jLabel8);
        jLabel8.setBounds(390, 660, 40, 30);

        mealnum.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                mealnumKeyTyped(evt);
            }
        });
        getContentPane().add(mealnum);
        mealnum.setBounds(990, 660, 70, 30);

        jLabel2.setIcon(new javax.swing.ImageIcon("E:\\Code\\NetBeans\\UI Image\\#JavaProject\\Calender\\208960-OZUKI2-299.png")); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 1300, 700);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
        int ch = JOptionPane.showConfirmDialog(null, "Do you want to exit?", "Exit?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (ch == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_b1ActionPerformed

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
        this.setState(P00002__Main_01.ICONIFIED);
    }//GEN-LAST:event_b2ActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened

    }//GEN-LAST:event_formWindowOpened

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        P00002__Main_2 Main = new P00002__Main_2();
        Main.setVisible(true);
        Main.setLocationRelativeTo(null);
        Main.setTitle("Meal Management");
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String ids = id.getText();
        String dat = date.getText();
        String mealD = mealnum.getText();
         
        int tmeal, dati, idi;
        if(ids.length()!=0 && dat.length()!=0 && mealD.length()!=0){
            dati = Integer.valueOf(dat);
            idi = Integer.valueOf(ids); 
            tmeal = P000001__ReadInformation_1.counttotalmeal(ids);
            if (dati <= maxday && dati > 0 && idi <= membr && idi > 0 ) {
                Connection con = P000001__CreateConnection_1.ConnectDb("StudentInfo.db");

                int dic=P000001__EditImfo_1.editInfo(con, "StudentInfo", caldate[Integer.valueOf(dat) - 1], "ID", mealD, ids);
                if(dic==1)
                {
                    JOptionPane.showMessageDialog(null, "Update successfull");
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Failed");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Invalid Value");
            }
        } else {
                JOptionPane.showMessageDialog(null, "Invalid Value");
        }
        if(P000001__EditImfo_1.updateTotalMealMoney()==1)
        {
            JOptionPane.showMessageDialog(null, "Total information successfull");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Total information failed");
        }
        updateTable();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void dateKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dateKeyTyped
        char c = evt.getKeyChar();
        if (!(Character.isDigit(c)) || (c == KeyEvent.VK_BACKSPACE) || (c == KeyEvent.VK_DELETE)) {
            evt.consume();
        }
    }//GEN-LAST:event_dateKeyTyped

    private void idKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_idKeyTyped
        char c = evt.getKeyChar();
        if (!(Character.isDigit(c)) || (c == KeyEvent.VK_BACKSPACE) || (c == KeyEvent.VK_DELETE)) {
            evt.consume();
        }
    }//GEN-LAST:event_idKeyTyped

    private void mealnumKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mealnumKeyTyped
        char c = evt.getKeyChar();
        if (!(Character.isDigit(c)) || (c == KeyEvent.VK_BACKSPACE) || (c == KeyEvent.VK_DELETE)) {
            evt.consume();
        }
    }//GEN-LAST:event_mealnumKeyTyped

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        String dates = date.getText();
        
        if(dates.length()!=0)
        {
            int d = Integer.valueOf(dates);
            if(d <= maxday)
            {
                String meald = P000001__ReadInformation_1.ReadSingleInfo("UserInfo.db", "Rule", "Meal_PerDay");

                for(int i=1; i<=membr; i++)
                {
                    Connection con = P000001__CreateConnection_1.ConnectDb("StudentInfo.db");
                    P000001__EditImfo_1.editInfo(con, "StudentInfo", caldate[d-1], "ID", meald, String.valueOf(i));
                }
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Invalid Value");
            }
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Invalid Value");
        }
        if(P000001__EditImfo_1.updateTotalMealMoney()==1)
        {
            JOptionPane.showMessageDialog(null, "Total information successfull");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Total information failed");
        }
        updateTable();
        
    }//GEN-LAST:event_jButton3ActionPerformed

    public static void main(String args[]) {
//        P00003__MonthlyDetail_1 Main = new P00003__MonthlyDetail_1();
//        Main.setVisible(true);
//        Main.setLocationRelativeTo(null);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable T1;
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JTextField date;
    private javax.swing.JTextField id;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField mealnum;
    private javax.swing.JLabel year;
    private javax.swing.JLabel year1;
    // End of variables declaration//GEN-END:variables
}
