/*******************************************************************************
 * #Author:   SRPPC
 * #Mail:     shajedurrahmanpanna.panna@gmail.com
 * #Date:     Sep 22, 2019
 * #Time:     10:36:00 PM
 * #File:     P000__CreatingDataBase_1
 * #Project:  _JavaProject_1
 ******************************************************************************/

package javaproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class P000001__DataBase_1 {
    public static Connection CreateDataBase(String DB_Location, String Name_DB_File)
    {        
//        System.out.println(DB_Location.length());
        try
        {
            Connection con;
            Class.forName("org.sqlite.JDBC");
            if(DB_Location.length()!=0) 
                con = DriverManager.getConnection("jdbc:sqlite:"+DB_Location+"/"+Name_DB_File);
            
            else 
                con = DriverManager.getConnection("jdbc:sqlite:"+Name_DB_File);
            
            return con;       
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
    
    public static boolean CreateTable(String DB_Location, String Name_DB_File, String TableName, ArrayList<String> ColumnName)
    {
        P000001__File_1.CreateFile(DB_Location);
        Connection con = CreateDataBase(DB_Location, Name_DB_File);
        if(con!=null)
        {
            try {
                StringBuffer st = new StringBuffer("CREATE TABLE IF NOT EXISTS " + TableName + " (\n");
                Statement stm = con.createStatement();
                int al_size = ColumnName.size();
                al_size--;
                
                for (int i = 0; i < al_size; i++) 
                {
//                    System.out.println(ColumnName.get(i));
                    st.append(ColumnName.get(i)+",\n");
                }
                st.append(ColumnName.get(al_size)+"\n");
                st.append(");");
                
//                System.out.println(st);
                
                stm.execute(String.valueOf(st));
                
                return true;
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex);
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    
//    public static void main(String[] args) {
//        ArrayList<String> ColumnName = new ArrayList<String>();
//        
//        ColumnName.add("aaaa integer");
////        ColumnName.add("name text");
////        ColumnName.add("capacity text");
//        
//        CreateTable("", "DB.db", "Info", ColumnName);
//    }
}
