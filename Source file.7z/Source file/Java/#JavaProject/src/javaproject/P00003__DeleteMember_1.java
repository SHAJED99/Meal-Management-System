/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaproject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class P00003__DeleteMember_1 extends javax.swing.JFrame {

    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    public P00003__DeleteMember_1() {
        initComponents();

        updateTable();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        T1 = new javax.swing.JTable();
        idt = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        b1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        b2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        unt = new javax.swing.JTextField();
        pt = new javax.swing.JPasswordField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(800, 544));
        setMinimumSize(new java.awt.Dimension(800, 544));
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(800, 544));
        setSize(new java.awt.Dimension(800, 544));
        getContentPane().setLayout(null);

        T1.setAutoCreateRowSorter(true);
        T1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        T1.setFont(new java.awt.Font("Tahoma", 0, 9)); // NOI18N
        T1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NAME", "MOBILE", "P_MOBILE"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        T1.setEnabled(false);
        T1.setFocusable(false);
        T1.setGridColor(new java.awt.Color(0, 0, 0));
        T1.setRequestFocusEnabled(false);
        T1.setRowHeight(20);
        T1.setRowSelectionAllowed(false);
        T1.setSelectionBackground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(T1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(30, 70, 460, 450);
        getContentPane().add(idt);
        idt.setBounds(620, 150, 130, 30);

        jButton1.setBackground(new java.awt.Color(54, 141, 167));
        jButton1.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton1.setText("Back");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.setBorderPainted(false);
        jButton1.setFocusable(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(520, 450, 90, 30);

        b1.setBackground(new java.awt.Color(54, 141, 167));
        b1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        b1.setText("X");
        b1.setToolTipText("Exit");
        b1.setBorderPainted(false);
        b1.setContentAreaFilled(false);
        b1.setFocusable(false);
        b1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        b1.setMaximumSize(new java.awt.Dimension(7, 15));
        b1.setMinimumSize(new java.awt.Dimension(7, 15));
        b1.setPreferredSize(new java.awt.Dimension(7, 15));
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1ActionPerformed(evt);
            }
        });
        getContentPane().add(b1);
        b1.setBounds(760, 40, 30, 30);

        jButton2.setBackground(new java.awt.Color(54, 141, 167));
        jButton2.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton2.setText("Next");
        jButton2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton2.setBorderPainted(false);
        jButton2.setFocusable(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(660, 450, 90, 30);

        b2.setBackground(new java.awt.Color(54, 141, 167));
        b2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        b2.setText("-");
        b2.setToolTipText("Minimize");
        b2.setBorderPainted(false);
        b2.setContentAreaFilled(false);
        b2.setFocusPainted(false);
        b2.setMargin(new java.awt.Insets(-5, 0, 0, 0));
        b2.setMaximumSize(new java.awt.Dimension(7, 15));
        b2.setMinimumSize(new java.awt.Dimension(7, 15));
        b2.setPreferredSize(new java.awt.Dimension(7, 15));
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });
        getContentPane().add(b2);
        b2.setBounds(730, 10, 30, 30);

        jLabel3.setText("USER NAME");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(510, 280, 70, 30);

        jLabel1.setText("ID");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(510, 150, 100, 30);

        jLabel4.setText("PASSWORD");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(510, 340, 70, 30);

        jLabel5.setText("ADMIN USER & PASSWORD");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(560, 230, 170, 30);

        unt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(unt);
        unt.setBounds(590, 280, 170, 30);
        getContentPane().add(pt);
        pt.setBounds(590, 340, 170, 30);

        jLabel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(jLabel6);
        jLabel6.setBounds(500, 130, 270, 290);

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("Present Information");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(180, 30, 150, 30);

        jLabel2.setIcon(new javax.swing.ImageIcon("E:\\Code\\NetBeans\\UI Image\\#JavaProject\\Delete\\208960-OZUKI2-299.png")); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 800, 544);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
        int ch = JOptionPane.showConfirmDialog(null, "Do you want to exit?", "Exit?", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (ch == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_b1ActionPerformed

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
        this.setState(P00002__Main_01.ICONIFIED);
    }//GEN-LAST:event_b2ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        int d = P000001__ReadInformation_1.MatchPassword(unt.getText(), pt.getText());
        if (d == 1 || d == 2) {
            int dd = JOptionPane.showConfirmDialog(null, "Do you want to delete ID " + idt.getText(), "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

            if (dd == JOptionPane.YES_OPTION) {
                int x = P000001__DeleteMember_1.delete("StudentInfo.db", "StudentInfo", "ID", idt.getText());
                if (x == 1) {
                    JOptionPane.showMessageDialog(null, "Updated");
                } else {
                    JOptionPane.showMessageDialog(null, "ID " + idt.getText() + " not found. Task Failed");
                }
            }
            updateTable();
        } else {
            JOptionPane.showMessageDialog(null, "Wrong Password");
        }


    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        P00002__Main_3 main = new P00002__Main_3();
        main.setVisible(true);
        main.setLocationRelativeTo(null);
        main.setTitle("Meal Management");
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    public void updateTable() {
        DefaultTableModel model = new DefaultTableModel();
        Object col1[] = {"ID", "NAME", "MOBILE", "P_MOBILE"};
        model.setColumnIdentifiers(col1);
        T1.setModel(model);
        con = P000001__CreateConnection_1.ConnectDb("StudentInfo.db");
        if (con != null) {
            String sql = "Select ID, NAME, MOBILE, P_MOBILE from StudentInfo";

            try {
                pst = con.prepareStatement(sql);
                rs = pst.executeQuery();
                Object[] columnData = new Object[4];
                while (rs.next()) {
                    columnData[0] = rs.getString("ID");
                    columnData[1] = rs.getString("NAME");
                    columnData[2] = rs.getString("MOBILE");
                    columnData[3] = rs.getString("P_MOBILE");
                    model.addRow(columnData);

                }
                con.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }

    public static void main(String args[]) {
//        P00003__DeleteMember_1 DeleteMember = new P00003__DeleteMember_1();
//        DeleteMember.setVisible(true);
//        DeleteMember.setLocationRelativeTo(null);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable T1;
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JTextField idt;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPasswordField pt;
    private javax.swing.JTextField unt;
    // End of variables declaration//GEN-END:variables
}
