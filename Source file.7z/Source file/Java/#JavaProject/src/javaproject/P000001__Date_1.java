/*******************************************************************************
 * #Author:   SRPPC
 * #Mail:     shajedurrahmanpanna.panna@gmail.com
 * #Date:     Sep 16, 2019
 * #Time:     8:02:46 PM
 * #File:     P000001__Date_1
 * #Project:  _JavaProject
 ******************************************************************************/

package javaproject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class P000001__Date_1 {
    public static int Today_dd()
    {
        Date day = new Date();
        DateFormat date = new SimpleDateFormat("dd");
        String format_mdy = date.format(day);
        return Integer.valueOf(format_mdy);
    }
    
    public static int Today_MM()
    {
        Date day = new Date();
        DateFormat date = new SimpleDateFormat("MM");
        String format_mdy = date.format(day);
        return Integer.valueOf(format_mdy);
    }
    
    public static int Today_YY()
    {
        Date day = new Date();
        DateFormat date = new SimpleDateFormat("YYYY");
        String format_mdy = date.format(day);
        return Integer.valueOf(format_mdy);
    }
    
//    public static void main(String[] args) {
//        int date = P000001__Date_1.Today_YY();
//    }
}
