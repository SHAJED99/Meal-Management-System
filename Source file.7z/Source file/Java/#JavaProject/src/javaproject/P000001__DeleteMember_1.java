/** *****************************************************************************
 * #Author:   SRPPC
 * #Mail:     shajedurrahmanpanna.panna@gmail.com
 * #Date:     Sep 16, 2019
 * #Time:     2:21:32 AM
 * #File:     P000001__DeleteMember_1
 * #Project:  _JavaProject
 ***************************************************************************** */
package javaproject;

import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class P000001__DeleteMember_1 {

    public static int delete(String DataBase, String DataBase_Name, String ID_Name, String ID) {
        Connection con = P000001__CreateConnection_1.ConnectDb(DataBase);

        if (con != null) {
            try {
                Statement stmt = con.createStatement();
                String q1 = "DELETE from " + DataBase_Name + " WHERE " + ID_Name + " = '" + ID + "'";
                int x = stmt.executeUpdate(q1);
                con.close();
                if(x>0)
                    return 1;
                else 
                    return 0;

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
                return -1;
            }
        } else {
            JOptionPane.showMessageDialog(null, "DataBase Error");
            return -1;
        }
    }
}
