/** *****************************************************************************
 * #Author:   SRPPC
 * #Mail:     shajedurrahmanpanna.panna@gmail.com
 * #Date:     Sep 18, 2019
 * #Time:     1:14:43 AM
 * #File:     P000001__MakeTaka0_1
 * #Project:  _JavaProject
 ***************************************************************************** */
package javaproject;

import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class P000001__MakeTaka0_1 {

    public static int make0(String ID, String NAME) {
        String[] caldate = {"one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty", "twentyone", "twentytwo", "twentythree", "twentyfour", "twentyfive", "twentysix", "twentyseven", "twentyeight", "twentynine", "thirty", "thirtyone"};
        Connection con = P000001__CreateConnection_1.ConnectDb("StudentInfo.db");
        if (con != null) {
            try {
                Statement smt = con.createStatement();
                int smtc = 0;

                for (int i = 1, date=0; i <= 31; i++,date++) {
                    String q = "UPDATE StudentInfo set " + caldate[date] + " = '0' WHERE ID = '" + ID + "' AND NAME = '" + NAME + "'";

                    smtc = smtc + smt.executeUpdate(q);
                }
                if (smtc > 0) {

                    con.close();
                    return smtc;
                } else {
                    con.close();
                    return 0;
                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
                return -1;
            }

        } else {
            JOptionPane.showMessageDialog(null, "DataBase Error");
            return -1;
        }
    }

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, make0("1", "qssqs"));
    }
}
