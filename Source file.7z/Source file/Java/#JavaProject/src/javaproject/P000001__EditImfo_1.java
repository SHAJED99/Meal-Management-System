/** *****************************************************************************
 * #Author:   SRPPC
 * #Mail:     shajedurrahmanpanna.panna@gmail.com
 * #Date:     Sep 15, 2019
 * #Time:     2:59:13 AM
 * #File:     P000001__EditUserNamePassword_1
 * #Project:  _JavaProject
 ***************************************************************************** */
package javaproject;

import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class P000001__EditImfo_1 {

    public static int editInfo(Connection con, String USER_PASSWORD, String USER_NAME, String USER_NAME_id, String NEW, String OLD)///1 for done; 0 for fail; -1 for error
    {
        if (con != null) {
            try {
                Statement smt = con.createStatement();

                String q = "UPDATE " + USER_PASSWORD + " set " + USER_NAME + " = '" + NEW + "' WHERE " + USER_NAME_id + " = '" + OLD + "'";

                int smtc = smt.executeUpdate(q);

                if (smtc > 0) {

                    con.close();
                    return 1;
                } else {
                    con.close();
                    return 0;
                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
                return -1;
            }

        } else {
            JOptionPane.showMessageDialog(null, "DataBase Error");
            return -1;
        }
    }

    public static int editInfo(Connection con, String USER_PASSWORD, String USER_NAME, String NEW_u, String OLD_u, String PASSWORD, String NEW_p, String OLD_p)///1 for done; 0 for fail; -1 for error
    {
        if (con != null) {
            try {
                Statement smt = con.createStatement();

                String q = "UPDATE " + USER_PASSWORD + " set " + USER_NAME + " = '" + NEW_u + "' , " + PASSWORD + " = '" + NEW_p + "' WHERE " + USER_NAME + " = '" + OLD_u + "' AND " + PASSWORD + " = '" + OLD_p + "'";

                int smtc = smt.executeUpdate(q);

                if (smtc > 0) {

                    con.close();
                    return 1;
                } else {
                    con.close();
                    return 0;
                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
                return -1;
            }

        } else {
            JOptionPane.showMessageDialog(null, "DataBase Error");
            return -1;
        }
    }
    
    public static int updateTotalMealMoney()
    {
        int membr = P000001__CountMember_1.countmemberint("StudentInfo.db", "StudentInfo", "ID");
        Connection con=P000001__CreateConnection_1.ConnectDb("StudentInfo.db");
        if(con!=null)
        {
            try
            {
                int ans=0;
                for(int i = 1; i<=membr; i++)
                {
                    int tm=P000001__ReadInformation_1.counttotalmeal(String.valueOf(i));
                    con=P000001__CreateConnection_1.ConnectDb("StudentInfo.db");
                    ans=ans+P000001__EditImfo_1.editInfo(con, "StudentInfo", "TOTAL_MEAL", "ID", String.valueOf(tm), String.valueOf(i));
                }
                if(ans==membr)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
            catch(Exception e) {
                JOptionPane.showMessageDialog(null, e);
                return -1;
            }
        } else {
            JOptionPane.showMessageDialog(null, "DataBase Error");
            return -1;
        }
    }
}
