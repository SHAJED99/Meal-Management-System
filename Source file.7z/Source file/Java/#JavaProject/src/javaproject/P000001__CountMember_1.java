/*******************************************************************************
 * #Author:   SRPPC
 * #Mail:     shajedurrahmanpanna.panna@gmail.com
 * #Date:     Sep 15, 2019
 * #Time:     9:25:51 PM
 * #File:     P000001__CountMember_1
 * #Project:  _JavaProject
 ******************************************************************************/

package javaproject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class P000001__CountMember_1 {
    public static int countmember(String database_loc, String table_name, String mesure_id)
    {
        Connection con = P000001__CreateConnection_1.ConnectDb(database_loc);
        if(con == null)
        {
            return -1;
        }
        else
        {
            String sql = "Select " + mesure_id + " from " + table_name;
            
            try
            {
                int ret = 0;
                PreparedStatement pst = con.prepareStatement(sql);
                ResultSet rs = pst.executeQuery();
                
                while (rs.next()) {
                    ret = Integer.valueOf(rs.getString("ID"));
                }
                con.close();
                return ret;
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
                return -1;
            }    
        }
    }
    public static int countmemberint(String database_loc, String table_name, String mesure_id)
    {
        Connection con = P000001__CreateConnection_1.ConnectDb(database_loc);
        if(con == null)
        {
            return -1;
        }
        else
        {
            String sql = "Select " + mesure_id + " from " + table_name;
            
            try
            {
                int ret = 0;
                PreparedStatement pst = con.prepareStatement(sql);
                ResultSet rs = pst.executeQuery();
                
                while (rs.next()) {
                    ret++;
                }
                con.close();
                return ret;
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
                return -1;
            }    
        }
    }
}
