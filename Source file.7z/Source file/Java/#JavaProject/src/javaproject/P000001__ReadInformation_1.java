/** *****************************************************************************
 * #Author:   SRPPC
 * #Mail:     shajedurrahmanpanna.panna@gmail.com
 * #Date:     Sep 15, 2019
 * #Time:     2:32:36 AM
 * #File:     P000001__
 * #Project:  _JavaProject
 * For code help : https://www.geeksforgeeks.org/performing-database-operations-java-sql-create-insert-update-delete-select/
 ***************************************************************************** */
package javaproject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class P000001__ReadInformation_1 {

    public static int MatchPassword(String uuu, String ppp)/// 1,2 for access; 0 for no access; -1 for null
    {
        Connection con = P000001__CreateConnection_1.ConnectDb("UserInfo.db");
        if (con != null) {
            String sql = "Select USER_NAME, PASSWORD from USER_PASSWORD";

            try {
                PreparedStatement pst = con.prepareStatement(sql);
                ResultSet rs = pst.executeQuery();
                String un = rs.getString("USER_NAME");
                String pp = rs.getString("PASSWORD");

                if (un.length() == 0 && pp.length() == 0) {
                    con.close();
                    return 2;
                }

                if (un.equals(uuu) && pp.equals(ppp)) {
                    con.close();
                    return 1;
                } else {
                    con.close();
                    return 0;
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
                return -1;
            }
        } else {
            JOptionPane.showMessageDialog(null, "DataBase Error");
            return -1;
        }
    }

    public static String ReadSingleInfo(String DataBaseLocation, String TableName, String ColumnName) {
        Connection con = P000001__CreateConnection_1.ConnectDb(DataBaseLocation);
        if (con != null) {
            String sql = "Select " + ColumnName + " from " + TableName;

            try {
                PreparedStatement pst = con.prepareStatement(sql);
                ResultSet rs = pst.executeQuery();
                String un = rs.getString(ColumnName);
                con.close();
                return un;
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
                return null;
            }
        } else {
            JOptionPane.showMessageDialog(null, "DataBase Error");
            return null;
        }
    }

    public static String ReadSingleInfoFromTable(String DataBaseLocation, String TableName, String ColumnName, String ID, String NUM) {
        Connection con = P000001__CreateConnection_1.ConnectDb(DataBaseLocation);
        if (con != null) {
            String sql = "Select " + ColumnName + " from " + TableName + " Where " + ID + " = '" + NUM + "'";

            try {
                PreparedStatement pst = con.prepareStatement(sql);
                ResultSet rs = pst.executeQuery();
                String un = rs.getString(ColumnName);
                con.close();
                return un;
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
                return null;
            }
        } else {
            JOptionPane.showMessageDialog(null, "DataBase Error");
            return null;
        }
    }

    public static String ReadSingleInfoFromTable_noclose(String DataBaseLocation, String TableName, String ColumnName, String ID, String NUM) {
        Connection con = P000001__CreateConnection_1.ConnectDb(DataBaseLocation);
        if (con != null) {
            String sql = "Select " + ColumnName + " from " + TableName + " Where " + ID + " = '" + NUM + "'";
            System.out.println(sql);
            try {
                PreparedStatement pst = con.prepareStatement(sql);
                ResultSet rs = pst.executeQuery();
                String un = rs.getString(ColumnName);
                return un;
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
                return null;
            }
        } else {
            JOptionPane.showMessageDialog(null, "DataBase Error");
            return null;
        }
    }

    public static int counttotalmeal(String ID) {
        String[] caldate = {"one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty", "twentyone", "twentytwo", "twentythree", "twentyfour", "twentyfive", "twentysix", "twentyseven", "twentyeight", "twentynine", "thirty", "thirtyone"};
        int uuu = 0;
        Connection con = P000001__CreateConnection_1.ConnectDb("StudentInfo.db");

        if (con != null) {
//                System.out.println(sql);
            try {
                for (int i = 0; i < 31; i++) {
                    String sql = "Select " + caldate[i] + " from StudentInfo Where ID = '" + ID + "'";
                    PreparedStatement pst = con.prepareStatement(sql);
                    ResultSet rs = pst.executeQuery();
                    String un = rs.getString(caldate[i]);
                    uuu = uuu + Integer.valueOf(un);
                }
                con.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
                return -1;
            }
            return uuu;
        } else {
            JOptionPane.showMessageDialog(null, "DataBase Error");
            return -1;
        }
    }
    
    public static int aftermeal(String ID)
    {
        int i = Integer.valueOf(ID);
        int tm=P000001__ReadInformation_1.counttotalmeal(String.valueOf(i));
        int tmoney=Integer.valueOf(P000001__ReadInformation_1.ReadSingleInfoFromTable("StudentInfo.db", "StudentInfo", "MONEY", "ID", String.valueOf(i)));
        int permeal = Integer.valueOf(P000001__ReadInformation_1.ReadSingleInfo("UserInfo.db", "Rule", "Meal_Rate"));

        int aftmeal = tmoney - (tm*permeal);
        return aftmeal;
    }

//    public static void main(String[] args) {
//        System.out.println(P000001__ReadInformation_1.aftermeal("2"));
//    }
}
