/*******************************************************************************
 * #Author:   SRPPC
 * #Mail:     shajedurrahmanpanna.panna@gmail.com
 * #Date:     Sep 23, 2019
 * #Time:     2:05:29 AM
 * #File:     P002__CreateFile_1
 * #Project:  _JavaProject_1
 ******************************************************************************/

package javaproject;

import java.io.File;

public class P000001__File_1 {
    public static boolean CreateFile(String Location) {
        StringBuffer st = new StringBuffer(Location);
        
        File file = new File(String.valueOf(st));
        
        if((file.mkdirs()))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
